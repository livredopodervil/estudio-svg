RD Patch gerado pelo RD Studio/GIL. Instalar pelo painel Pacotes IA, vistoriar e publicar seletivamente.
